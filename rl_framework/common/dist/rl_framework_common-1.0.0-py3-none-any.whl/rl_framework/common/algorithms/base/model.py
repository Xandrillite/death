class Model(object):
    def __init__(self, *args):
        pass

    def inference(self, feature):
        raise NotImplementedError("build model: not implemented!")
