# -*- coding:utf-8 -*-

import unittest


class SysStatTest(unittest.TestCase):
    def setUp(self) -> None:
        pass

    def test_sys_stat(self):
        pass


if __name__ == "__main__":
    unittest.main()
